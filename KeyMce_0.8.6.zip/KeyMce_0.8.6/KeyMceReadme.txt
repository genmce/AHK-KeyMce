:::::::::::::::::::::: � Kip Chatterson 2009/2010 All Rights Reserved ::::::::::::::::::::::



Not for release - if you did not get this directly from me - you are not authorized to use it.

::::::::::::::::::
:: PROGRAM INFO ::
::::::::::::::::::

Program Name........: Keymce
Version.............: v0.80.1 beta
Author..............: Kip Chatterson
License Type........: to be determined
File Size...........: archive about 900k
OS..................: Win XP, not sure about vista or 7
Release Date........: November 3, 2010
Languages...........: English

:::::::::::::
:: CONTACT ::
:::::::::::::

Email...............: keymcesupport@gmail.com

:::::::::::::::::::::::::::::
:: DESCRIPTION or/and USES ::
:::::::::::::::::::::::::::::

"Leftcontrol" + "backspace" sends the sysex string to Sonar.

*Press the "pause key" on your keyboard to type.

*Right click on tray icon for setup as needed.
 
*Reopen project or daw after changing midi settings!

Create/Mix your music on the go - without a bulky external midi controller!
Control - faders/pans/sends/mutes/solos/arms in banks of 8 tracks (up to 48 tracks) along with a jog wheel on your mouse wheel, without mapping anything. Keep reading, there is more.
Designed for laptop - but works great on desktop too!
Who needs this?

    * Laptop users on the go, that don't want to haul a dedicated controller.
    * Limited budget users, this thing is cheap! (see below)
    * Limited workspace studios - takes up zero real estate!
    * Don't own a midi controller or want/need another?
    * Do you want a lot of control with minimal fuss?
    * Don't want to program/learn to program a controller or deal with all that hassle.
    * Do you record your own music on a PC?
    * Ablelton Live/Cubase(Nuendo)/Reaper user?


KeyMce changes your PC computer keyboard into a midi controller, sending midi messages similar to the Mackie Control Universal (tm mackie) to daw (digital audio workstation) for control of tracks 1- 48.

Faders, pans, sends, mutes, solos, arms, jog wheel, and more all premapped for ease of use.
Just select the control surface in daw, along with setting up KeyMce midi ports (virtual midi port required), reload project and enjoy.

It is that easy, try it today!



::::::::::::::
:: REQUIRED ::
::::::::::::::

US English QWERTY or German QWERTZ keylayout - Selectable on KeybdLayout tray menu item - Minimal system: p2, 256mg ram, WinXP.

EDIT .INI FILES, AT YOUR OWN RISK!

::::::::::::::::
::  Controls  ::
::::::::::::::::

Settings available with "right mouse click on tray Icon"

	KeybdLayout menu item = to select qwerty or qwertz. (qwerty default)


Faders - keys "a - z" 	  = up value tracks 1 - 8  	
	 keys "z - ,"     = down value
 	 "Esc + "a - Z" " = Reset faders to 0db 

Master fader -
   "ESC + Up row"         = Increase Master Fader value.
   "ESC + Down arrow"     = Decrease Master fader value. 
   "ESC + right arrow"    = set master fader to 0db
   "ESC + right arrow"    = Mute master fader
	
pans/sends (if using klinke mcu plugin reaper)
	up or left 	= "1 - 8"
	down or Right	= "q - i"

Bank keys 
	"[" = will bank back in increments of 8
	"]" = will bank up in incs of 8
     *What does this mean? 
      Tracks in mackie are broken into groups of 8.
      So you can control a group of 8 tracks - 1-8 (bank1) 9-16       
      (bank2) etc... 
      This program will bank as far as 48 tracks.

Jog Wheel
	"Left Control + mouse wheel up" 	= jog up
	"Left Control + mouse wheel down" 	= jog down
	
Button functions

Mute/Solo/Arm  = "F1 - F8" keys f1 - track 1, f2 - track 2. etc 
      multipresses
      "f1" - 1 push = mute - track 1, 
               2 pushes = solo - track 1, 
               3 pushes = arm - track 1
      "f2"  see above track 2 ...

Channel Select / Vpot Select = "left control  + (f1 - f8)" 
	multipresses
	"left Win + f1" Press "left Win" hold, then: 
                 Press "f1"  - 1 push = track 1 select, 
                               2 pushes = vpot select 
	
Other button funtions

	"f10" = flip - flip vpots and faders, 
			double press = returns (Live Only)
	"f11" = Plugins - 
			double press = EQ (Cube/Nuendo only)
	
	"left shift + f9" = fader speed
	"left ctrl + f9"   = vpot speed
	"left alt + f9"    = jog speed
	"f12" =  pan 
			 double press = sends
    
	"L" = loop toggle

	"Under revision" = --- Undo ---
	"Under revision"  = --- redo ---



::::::::::::::::
:: CHANGE LOG ::
::::::::::::::::

v. 0.80.1 Discontinued open sourc - old source will remain available.
	  Beverageware license reinstated.
	  Added built in LCD emulation.
          Sysex to connect ot Sonar on LeftCtrl + Backspace. 

v.0.60 arrays for vpots 
       sysex output to connect to sonar and AA and Logic, I hope.

v.0.54  Open Source - get on with my life!
	Changed to scancodes - any keylayout should work. Remember that the keys stated below are the physical locations
	of the commands. So the physical location of "Y" on qwerty is the same command as "Z" on qwertz. Location location 	location.

v.0.51 Changed numeric version
       Fixed problem with faders working properly.

v.0.50.2 Changed read only io.ini file, sorry.

v.0.0.50 BeverageWare discontinued - while it seemed like a good idea, it was not.
	 TrialWare engaged. 
         10 day trial period followed by registration key dialog.
         $10 USD donation for non - commercial license. See KeyMce_EULA.txt.
	 $20 USD donation for commercial used.	
         
	Features added - 
		- F9 = speed settings fixed
		- L = loop fixed for Reaper (broken after last version)
       		- esc + a-z = fader set to 0db.
		- Fixed vpot selects
                - Fixed broken qwertz layout keys.
		- Many functions for Cubase/Nuendo added too numerous to mention.

	TODO: 
		- add more keylayouts after getting more testers
		- add transports.
		- in
			
v.0.0.44 combo (not released)
	- Key changes 
		- F9  = speed settings
		- F11 = plugins / eq
		- GER_QWERTZ Keyboard layout differences
			- bank keys = umlauf u, +
			- fader one down = y, vpot 6 down = z
	- auto daw dections working
		- Auto mapping of keys to Cubase functions - if cubase running (not tested yet)
		- Auto for Nuendo (not tested)
		- Auto for live (tested)
		- auto for reaper (tested)
	- Added vpot selects back in (they were disabled previous releases)
	- keyboard layout selection added (on Tray Menu)- US_QWERTY is default, added GER_QWERTZ
	- Master fader set to 0 db should be fixed (not tested)
	
v.0.0.40 Auto daw detection, based on what is running. (not released)
	- added support for Cubase

V.0.0.37 BeverageWare

v.0.0.36 Revise midi selection (fixed)

v.0.0.35 initial beta tester release



:::::::::::::
:: LICENSE ::
:::::::::::::

See keymce_EULA.txt

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

:::::::::::::::::::::: � Kip Chatterson 2009/2010 All Rights Reserved ::::::::::::::::::::::
